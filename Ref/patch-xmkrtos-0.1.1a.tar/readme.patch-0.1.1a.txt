PATCH to update XMK RTOS v0.1.1 to v0.1.1a
================================================================================
This patch fixes a critical error in the low level interrupt handling for the
M16C port of the XMK Scheduler.  No other platforms are affected by this bug.


Required?
---------
This patch is only required if you are using the M16C platform.


How to Apply
------------
Copy/overwrite the contents of this patch tar file to the existing XMK source 
trees.


Files
-----
  src\xmk\platform\renesas\m16c\kernel\nc30\vector_macros.inc
