#include "tsk_10ms.h"			// For this module's definitions
#include "button.h"

void Tsk_10ms(void)
{
   Button_Debounce();
}

/*** End of File **************************************************************/

