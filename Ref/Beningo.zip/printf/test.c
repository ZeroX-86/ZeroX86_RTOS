
int Test(void)
{
	static int Variable = 12;
	
	return Variable++;
	
}
