#include <stdint.h>

void SysTick_Init(void);
uint32_t SysTick_Get(void);
