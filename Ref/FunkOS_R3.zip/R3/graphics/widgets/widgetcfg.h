#ifndef __WIDGETCFG_H_
#define __WIDGETCFG_H_

// #define the different widgets included in your project.


#endif
