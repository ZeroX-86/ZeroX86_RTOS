#include "task.h"
#include "scheduler.h"

FunkOS_Scheduler g_clScheduler;
